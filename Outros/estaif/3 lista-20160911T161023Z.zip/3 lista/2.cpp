#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>

/*Ler uma palavra e, se ela come�ar pela letra L ou D (ou l ou d), formar uma nova palavra que ter� os dois
primeiros caracteres e o �ltimo, caso contr�rio a nova palavra ser� formada por todos os caracteres menos o
primeiro caractere.*/

int main()
{
    setlocale(LC_ALL,"ptb");
	
	char p[100];
	int i,c=0;
	
	printf("Informe a frase \n");
	gets(p);
	
	strupr(p);
	
	for(i=0;i<strlen(p);i++){
		
		if(p[i]=='L' or p[i]=='D'){
			c++;
		}
		else{
			p[i]=0;
			
		}
		if(p[i]!=0){
			printf("%c",p[i]);
		}
	
			
		
	}

	if(c!=0){
		for(i=0;i<strlen(p);i++){
			if(i==0 or i==1 and p[strlen(p)-1]){
				printf("%c",p[i]);
			}
			
		}
			
	}



	printf("\n\n");
	system("pause");
	exit(1);

}






