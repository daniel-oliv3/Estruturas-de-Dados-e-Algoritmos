#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
/*Entrar com profiss�o de v�rias pessoas e imprimir quantas s�o dentistas (considere: Dentista, DENTISTA,
dentista)*/

int main()
{
    setlocale(LC_ALL,"ptb");
	char a[100];
	int i,j,cont=0;
	

	
	printf("\n\n");	
	
	strupr(a);
	
	for(i=0;i<4;i++){
		printf("Informe a frase \n");
		gets(a);
		strupr(a);
		if(strcmp(a,"DENTISTA")==0){
			cont++;
		}
		
	}
	if(cont!=0){
		printf("\nO total palavras dentista � de: %d \n",cont);
	}
	else{
		printf("\nN�o foi digitado a palavra denttista\n");
	}

	printf("\n\n");
	system("pause");
	exit(1);

}






