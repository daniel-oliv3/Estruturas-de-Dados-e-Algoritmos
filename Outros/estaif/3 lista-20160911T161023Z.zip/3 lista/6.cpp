#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>


int main()
{
    setlocale(LC_ALL,"ptb");

	char a[100];
	int i,j;
	
	printf("Informe a frase \n");
	gets(a);
	
	strupr(a);
	printf("\n\n");
	
	for(i=0;i<strlen(a);i++){
		
		for(j=0;j<strlen(a);j++){
			
			if(i+j<strlen(a)){
				printf("%c",a[j]);
			}						
		}
		printf("\n\n");
	}
	
	
	printf("\n\n");
	system("pause");
	exit(1);


}





