#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
/*Criar um algoritmo que entre com uma palavra e imprima conforme o exemplo a seguir:
Palavras: PAZ
ZAP*/

int main()
{
    setlocale(LC_ALL,"ptb");
	char p[100];
	int i;
	
	printf("Informe a frase \n");
	gets(p);
	
	strrev(p);
	strupr(p);

	printf("\n\n");
	
	for(i=0;i<strlen(p);i++){
		printf("%c",p[i]);	
	}

	printf("\n\n");
	system("pause");
	exit(1);

}






