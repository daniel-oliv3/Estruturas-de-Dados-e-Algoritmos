#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
/*Entrar com uma mensagem e imprimir a quantidade de cada letra A, E, I, O e U que tem esta mensagem
(considerar min�scula e mai�scula). Ex: Brasil pa�s tropical. A=3, E=0, I=3, O=1, U=0*/

int main()
{
    setlocale(LC_ALL,"ptb");
	char a[100];
	int i,x[5];
	x[0]=0;
	printf("Informe a frase \n");
	gets(a);
	
	strupr(a);
	
	for(i=0;i<strlen(a);i++){
		
		if(a[i]=='A'){
			x[i]++;
		}
		if(a[i]=='E'){
			x[i]++;
		}
		if(a[i]=='I'){
			x[i]++;
		}
		if(a[i]=='O'){
			x[i]++;
		}
		if(a[i]=='U'){
			x[i]++;
		}				
		
	}
	
	
	for(i=0;i<5;i++){
	printf("%d\n",x[i]);
		
	}
	

	printf("\n\n");
	system("pause");
	exit(1);

}






