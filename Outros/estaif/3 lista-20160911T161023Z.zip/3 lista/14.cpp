#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
/*Pal�ndromos s�o palavras (frases tamb�m) que s�o iguais quando lidas de frente para tr�s e de tr�s para
frente, ignorando os espa�os. Portanto, fa�a um programa que seja capaz de dizer se a frase lida � ou n�o
pal�ndromo.
AME O POEMA AMOR A ROMA ATE O POETA LUZ AZUL */

int main()
{
    setlocale(LC_ALL,"ptb");

	char a[100],x[100];
	int cont=0,i,j;
	
	printf("Informe a frase \n");
	scanf("%s",&a);
	
	printf("\n\n");	
	
	strcpy(x,a);
	strrev(x);

	
	strlen(a);
	
	for(i=0;i<strlen(a);i++){
	
		if(a[i]==x[i]){
			cont++;
		}
		
	}
	if(cont==strlen(a)){
		printf("Esta palavra � um pal�ndromo\n");
	}
	else{
		printf("Esta palavra n�o � um pal�ndromo\n");
	}


	printf("\n\n");
	system("pause");
	exit(1);

}






