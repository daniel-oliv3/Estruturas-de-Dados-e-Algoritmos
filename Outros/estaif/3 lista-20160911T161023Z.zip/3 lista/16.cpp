#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
/*Criar um algoritmo que funcione atrav�s do menu a seguir: (OBS: para fazer o menu use a refer�ncia
SCHILDT, H., C completo e total, uso do switch case)
MENU
1 � Imprime o comprimento da frase
2 � Imprime os dois primeiros e os dois �ltimos caracteres da frase
3 � Imprime a frase espelhada
4 � Termina o algoritmo */

int main()
{
    setlocale(LC_ALL,"ptb");

	char a[100];
	int op,i,j;
	
	printf("Informe a frase \n");
	scanf("%s",&a);
	
	printf("1 � Imprime o comprimento da frase\n2 � Imprime os dois primeiros e os dois �ltimos caracteres da frase\n3 � Imprime a frase espelhada\n4 � Termina o algoritmo\n\n\n");
	scanf("%d",&op);
	
	switch(op){
		case 1:printf("O comprimento da frase � de %d: \n",strlen(a));break;
		case 2:printf("Os dois primeiros e dois ultimos caracteres %c%c%c%c\n",a[0],a[1],a[strlen(a)-2],a[strlen(a)-1]);break;
		case 3:printf("A frase espelhada:%s \n",strrev(a));break;
		case 4:exit(1);
		default: printf("Informe um valor valido\n");
	}
	
	printf("\n\n");	

	printf("\n\n");
	system("pause");
	exit(1);

}






