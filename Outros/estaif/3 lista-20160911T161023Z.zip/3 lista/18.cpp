#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
/*Fa�a um programa que receba uma frase e mostre as letras que se repetem, junto com o n�mero de
repeti��es:
Exemplo:
A PROVA FOI ADIADA.
- a letra A apareceu 5 vezes.
- a letra O apareceu 2 vezes.
- a letra I apareceu 2 vezes.
- a letra D apareceu 2 vezes.*/

int main()
{
    setlocale(LC_ALL,"ptb");
	char a[100];
	int i,x[4];
		
	printf("Informe a frase \n");
	gets(a);
	
	strupr(a);
	
	for(i=0;i<strlen(a);i++){
		if(a[i]=='A'){
			x[i]++;
		}
		else if(a[i]=='O'){
			x[i]++;	
		}
		else if(a[i]=='I'){
			x[i]++;	
		}
		else if(a[i]=='D'){
			x[i]++;	
		}
	}
	printf("\na letra A apareceu %d vezes.\na letra O apareceu %d vezes\na letra I apareceu %d vezes\na letra D apareceu %d vezes\n",x[0],x[1],x[2],x[3]);
	

	printf("\n\n");
	system("pause");
	exit(1);

}






