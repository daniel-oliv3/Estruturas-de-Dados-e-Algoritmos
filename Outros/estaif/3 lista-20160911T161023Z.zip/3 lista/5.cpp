#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>

int main()
{
    setlocale(LC_ALL,"ptb");
	char p[100];
	int i,j;
	
	printf("Informe a frase \n");
	gets(p);
	
	strupr(p);
	
	printf("\n\n");
	
	for(i=0;i<strlen(p);i++){
		for(j=0;j<strlen(p);j++){
			if(i>=j){
				printf("%c",p[j]);	
			}	
		}	
		printf("\n");
	}


	printf("\n\n");
	system("pause");
	exit(1);

}






