#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
/*17. Fa�a um programa para criptografar uma frase dada pelo usu�rio ( a criptografia troca as vogais da frase
por * ).
Exemplo:
EU ESTOU NA ESCOLA
** *ST** N* *SC*L* */

int main()
{
    setlocale(LC_ALL,"ptb");
	char a[100];
	int i;
		
	printf("Informe a frase \n");
	gets(a);
	
	strupr(a);
	
	for(i=0;i<strlen(a);i++){
		if(a[i]=='A' or a[i]=='E' or a[i]=='I' or a[i]=='O' or a[i]=='U'){
			a[i]='*';
		}
	}
	
	printf("\nA nova frase %s\n",a);
	
		


	printf("\n\n");
	system("pause");
	exit(1);

}






