#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#define l 3
#define c 3
/*Entrar com um nome e imprimir:
a. Todo nome;
b. Primeiro caractere;
c. Do primeiro at� o terceiro caractere;
d. O quarto caractere;
e. Todos menos o primeiro caractere;
f. Os dois �ltimos caracteres.*/

int main()
{
    setlocale(LC_ALL,"ptb");
	
	char nome[10];
	int j;

	printf("Informe a frase \n");
	gets(nome);
	
	
	printf("Essa � a frase: %s \n\n",nome);
	printf("O primeiro caracter da frase: %c \n\n",nome[0]);
	printf("Do primeiro at� o terceiro \n\n");
	
	for(j=0;j<3;j++){
		printf("%c",nome[j]);
	}
	printf("\nO quarto caracter da frase: %c \n\n",nome[3]);
	printf("Todos menos o primeiro\n\n");
	
	for(j=1;j<strlen(nome);j++){
		printf("%c",nome[j]);
	}
	
	printf("\nOs dois ultimos\n\n");
	
	printf("%c",nome[strlen(nome)-2]);
	printf("%c",nome[strlen(nome)-1]);
	
	

	printf("\n\n");
	system("pause");
	exit(1);

}






