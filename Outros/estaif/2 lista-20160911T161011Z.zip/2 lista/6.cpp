#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#define l 5
#define c 5
/* */

int main()
{
    setlocale(LC_ALL,"ptb");
	
	int i,j,a[l][c],s1=0,s2=0,s3=0,s4=0,s5=0;
	
	srand(time(NULL));
	
	printf("\nArray Original\n");

	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			a[i][j]=rand()%10;
			s5+=a[i][j];
			printf(" %5d ",a[i][j]);
			if(i==3){
				s1+=a[i][j];
			}
			if(j==1){
				s2+=a[i][j];
			}
			if(i==j){
				s3+=a[i][j];
			}
			if(i+j==l-1){
				s4+=a[i][j];
			}		
		}
		printf("\n\n");
	}
	
	printf("- a soma dos elementos da linha 4 %d\n- a soma dos elementos da coluna 2 %d\n- a soma dos elementos da diagonal principal %d\n- a soma dos elementos da diagonal secund�ria %d\n- soma de todos os elementos do array %d\n",s1,s2,s3,s4,s5);
	
	printf("\n\n");
	system("pause");
	exit(1);

}






