#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#define l 4
#define c 4
/* */

int main()
{
    setlocale(LC_ALL,"ptb");
	
	int i,j,a[l][c];
	srand(time(NULL));
	
	printf("\nArray Original\n");

	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			if(j>=i){
				a[i][j]=rand()%10;
				printf(" %5d ",a[i][j]);
			}
			else{
				a[i][j]=0;
				printf(" %5d ",a[i][j]);
			}
		}
		printf("\n\n");
	}

	printf("\n\n");
	system("pause");
	exit(1);

}






