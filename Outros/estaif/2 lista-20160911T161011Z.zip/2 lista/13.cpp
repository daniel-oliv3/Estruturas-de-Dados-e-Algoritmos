#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#define l 10
#define c 3
/*Fa�a um programa que leia um array bidimensional para armazenar as notas de tr�s provas de 10 alunos.
Em seguida, calcule e escreva na tela o n�mero de alunos cuja pior nota foi na prova 1, o n�mero de alunos
cuja pior nota foi na prova 2 e o n�mero de alunos cuja a pior nota foi na prova 3: */

int main()
{
    setlocale(LC_ALL,"ptb");

	int a[l][c],i,j,aux,cont1=0,cont2=0;
	
	/*for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			scanf("%d",&a[i][j]);		
		}
	}
	*/
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			a[i][j]=rand()%10;
			printf("  %d  ",a[i][j],i,j);		
		}		
		printf("\n\n");
	}

	for(i=0;i<l;i++){
		
		aux=a[i][0];
		cont1=0;
		
		for(j=0;j<c;j++){
		
			if(aux>a[i][j])
				cont1++;
			
		}	
		if(cont1==0)
			cont2++;	
		
	}
	
	printf("\n\nA quantidade de alunos que a pior nota foi a prova 1 foi de %d: \n",cont2);
	
	cont2=0;
	
	for(i=0;i<l;i++){
		cont1=0;
		aux=a[i][1];
		for(j=0;j<c;j++){
			if(aux>a[i][j])
				cont1++;
			
		}	
		if(cont1==0)
			cont2++;	
			
	}
	
	printf("\n\nA quantidade de alunos que a pior nota foi a prova 2 foi de %d: \n",cont2);
	
	cont2=0;
	
	for(i=0;i<l;i++){
		
		aux=a[i][2];
		cont1=0;
		
		for(j=0;j<c;j++){
			if(aux>a[i][j])
				cont1++;
			
		}	
		if(cont1==0)
			cont2++;	
		
	}
	
	printf("\n\nA quantidade de alunos que a pior nota foi a prova 3 foi de %d: \n",cont2);
	
	
	
	system("pause");
	exit(1);

}





