#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#define l 3
#define c 5
/*A gerente do cabeleireiro Sempre Bela tem uma tabela em que registra seus atendimentos, informando
quantos clientes fizeram os �p�s� as �m�os� e o servi�o de podologia das cinco manicures que trabalham
para ela. Sabendo-se que cada uma ganha 50% do que faturou ao m�s, criar um programa que possa
calcular e imprimir quanto cada uma vai receber, uma vez que n�o t�m carteiras assinadas; os valores dos
servi�os, respectivamente, s�o R$ 10,00; R$ 15,00 e R$ 30,00:*/

int main()
{
    setlocale(LC_ALL,"ptb");
	
		
	double ven[l][c],t[c];
	int i,j;
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			ven[i][j]=1+rand()%5;
			if(j==0){
				t[j]+=ven[i][j];
			}
			else if(j==1){
				t[j]+=ven[i][j];
			}
			else if(j==2){
				t[j]+=ven[i][j];
			}
			else if(j==3){
				t[j]+=ven[i][j];
			}
			else if(j==4){
				t[j]+=ven[i][j];
			}
				
			printf("  %.2lf  ",ven[i][j]);
		}
		printf("\n\n");
	}

	for(i=0;i<c;i++){
		printf("A %d� Empregada faturou o montande de %.2f\n",i+1,t[i]/2);
	}
	printf("\n\n");
	system("pause");
	exit(1);

}






