#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#define l 6
#define c 6
/* */

int main()
{
    setlocale(LC_ALL,"ptb");
	int i,j,a[l][c];
	srand(time(NULL));
	
	printf("\nArray Original\n");

	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			a[i][j]=rand()%10;
			printf(" %5d ",a[i][j]);
		}
		printf("\n\n");
	}
	printf("\nArray sem a diagonal principal\n");
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			if(i+j==l-1){
				printf("       ");	
			}
			else{
				printf(" %5d ",a[i][j]);
			}
		}
		printf("\n\n");
	}

	printf("\n\n");
	system("pause");
	exit(1);

}






