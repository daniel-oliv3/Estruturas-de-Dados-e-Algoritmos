#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#define l 10
#define c 5
/* */

int main()
{
    setlocale(LC_ALL,"ptb");

	int i,j;
	float a[l][c],max;
	srand(time(NULL));
	
	printf("\nArray Original\n");

	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			a[i][j]=rand()%10;
			printf(" %5.1f ",a[i][j]);
		}
		printf("\n\n");
	}
	
	for(i=0;i<l;i++){
		for(j=0;j<=0;j++){
			if(i==0){
				max=a[i][j];
			}
			else if(a[i][j]>max){
				max=a[i][j];
			}
		}
	}
	printf("\nO maior da 1 delega��o: %.1f\n",max);
	max=0.0;
		for(i=0;i<l;i++){
		for(j=1;j<=1;j++){
			if(i==0){
				max=a[i][j];
			}
			else if(a[i][j]>max){
				max=a[i][j];
			}
		}
	}
	printf("\nO maior da 2 delega��o: %.1f\n",max);
	max=0.0;
	
		for(i=0;i<l;i++){
		for(j=2;j<=2;j++){
			if(i==0){
				max=a[i][j];
			}
			else if(a[i][j]>max){
				max=a[i][j];
			}
		}
	}
	printf("\nO maior da 3 delega��o: %.1f\n",max);
	max=0.0;
		for(i=0;i<l;i++){
		for(j=3;j<=3;j++){
			if(i==0){
				max=a[i][j];
			}
			else if(a[i][j]>max){
				max=a[i][j];
			}
		}
	}
	printf("\nO maior da 4 delega��o: %.1f\n",max);
	max=0.0;
		for(i=0;i<l;i++){
		for(j=4;j<=4;j++){
			if(i==0){
				max=a[i][j];
			}
			else if(a[i][j]>max){
				max=a[i][j];
			}
		}
	}
	printf("\nO maior da 5 delega��o: %.1f\n",max);
	max=0.0;
	
	printf("\n\n");
	system("pause");
	exit(1);

}






