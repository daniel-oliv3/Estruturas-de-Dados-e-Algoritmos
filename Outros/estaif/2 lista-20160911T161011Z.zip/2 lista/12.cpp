#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#define l 6
#define c 6
/*Fa�a um programa que leia um array bidimensional de tamanho 4 x 4 com valores num�ricos inteiros e
positivos. Imprimir o array com os valores ordenados sequencialmente por linha em ordem crescente: */

int main()
{
    setlocale(LC_ALL,"ptb");
	
	int a[l][c],i,j,k,m,x;
	
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			a[i][j]=rand()%100;
			printf(" %4d ",a[i][j]);
		}		
		printf("\n\n");
	}
	
	printf("\n\n");
	printf("\n\n");
	printf("\n\n");
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			for(k=0;k<l;k++){
				for(m=0;m<c;m++){
					if(a[i][j]<a[k][m]){
						x=a[i][j];
						a[i][j]=a[k][m];
						a[k][m]=x;
					}
				}		
			}		
		}		
	}
	
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			printf(" %4d ",a[i][j]);
		}		
		printf("\n\n");
	}
	printf("\n\n");
	system("pause");
	exit(1);

}





