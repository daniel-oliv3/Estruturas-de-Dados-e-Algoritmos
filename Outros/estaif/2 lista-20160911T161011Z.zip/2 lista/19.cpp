#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#define l 12
#define c 4
/*Criar um programa que carregue um array bidimensional 12 x 4 com os valores das vendas de uma loja, em
que cada linha represente um m�s do ano, e cada coluna, uma semana do m�s. Para fins de simplifica��o
considere que cada m�s possui somente 4 semanas. Calcule e imprima:
- Total vendido em cada m�s do ano;
- Total vendido em cada semana durante todo o ano;
- Total vendido no ano.*/

int main()
{
    setlocale(LC_ALL,"ptb");
	
	double ven[l][c],t[l],st[c],totalano=0;
	int i,j;
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			ven[i][j]=1+rand()%5;
			
			printf("  %.2lf  ",ven[i][j]);
			
			if(i==0){
				t[i]+=ven[i][j];
			}
			else if(i==1){
				t[i]+=ven[i][j];
			}
			else if(i==2){
				t[i]+=ven[i][j];
			}
			else if(i==3){
				t[i]+=ven[i][j];
			}
			else if(i==4){
				t[i]+=ven[i][j];
			}
			else if(i==5){
				t[i]+=ven[i][j];
			}
			else if(i==6){
				t[i]+=ven[i][j];
			}
			else if(i==7){
				t[i]+=ven[i][j];
			}
			else if(i==8){
				t[i]+=ven[i][j];
			}
			else if(i==9){
				t[i]+=ven[i][j];
			}
			else if(i==10){
				t[i]+=ven[i][j];
			}
			else if(i==11){
				t[i]+=ven[i][j];
			}
			
			if(j==0){
				st[i]+=ven[i][j];
			}
			else if(j==1){
				st[i]+=ven[i][j];
			}
			else if(j==2){
				st[i]+=ven[i][j];
			}
			else if(j==3){
				st[i]+=ven[i][j];
			}
			
			totalano+=ven[i][j];						
		}		
		printf("\n\n");
	}
	for(i=0;i<l;i++){
		printf("Total vendido em cada m�s do ano: mes(%d) >> %.2lf\n",i+1,t[i]);
	}
	for(i=0;i<c;i++){
		printf("Total vendido em cada semana durante todo o ano: semana(%d) >> %.2lf\n",i+1,st[i]);
	}
	printf("Total vendido no ano: %.2f\n",totalano);

	printf("\n\n");
	system("pause");
	exit(1);

}






