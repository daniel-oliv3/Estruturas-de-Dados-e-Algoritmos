#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#define l 4
#define c 3
/* */

int main()
{
    setlocale(LC_ALL,"ptb");
    
    int a[l][c],i,j,b[l][c],y,x;
    
	printf("\nMatriz A\n\n");
    
    for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			a[i][j]=rand()%20;
			printf(" %4d ",a[i][j]);
		}		
		printf("\n\n");
	}
	printf("\n\n");
	
	printf("\nMatriz A transposta\n\n");
 	
	for(j=0;j<c;j++){
		for(i=0;i<l;i++){
			b[i][j]=a[i][j];
			printf(" %4d ",b[i][j]);
		}		
		
		printf("\n\n");
	}	
    
    

	printf("\n\n");
	system("pause");
	exit(1);

}





