#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#define l 5
#define c 5
/* */

int main()
{
    setlocale(LC_ALL,"ptb");
	
	int a[l][c],i,j,maior;
	
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			a[i][j]=rand()%10;
			printf(" %4d ",a[i][j]);
			if(i==0 and j==0){
				maior=a[i][j];
			}
			else if(a[i][j]>maior){
				maior=a[i][j];
			}
		}	
		printf("\n\n");
	} 
	
	printf("\nO maior �: %d\n",maior);
	
	printf("\n\n");
	system("pause");
	exit(1);

}





