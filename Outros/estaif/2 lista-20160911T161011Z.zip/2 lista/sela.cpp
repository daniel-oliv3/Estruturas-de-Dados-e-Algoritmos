#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>

int main(void){
   int a, b, c, d;
   // declara��o de vari�veis auxiliares

   scanf("%d", &a);
   
   int matriz[a][a], i[a], j[a], ij[a];
   // cria��o da matriz
   for(b=0; b<a; b++){
      for(c=0; c<a; c++){
         scanf("%d", &matriz[b][c]);
      }
   }
    for(b=0; b<a; b++){
      for(c=0; c<a; c++){
         printf(" %4d ",matriz[b][c]);
      }
      printf("\n\n");
   }
   // leitura da matriz

   for(b=0; b<a; b++){
      i[b] = matriz[b][0];
      for(c=1; c<a; c++){
         if(i[b]>matriz[b][c])
            i[b] = matriz[b][c];
      }
      //printf("%d\n", i[b]);
   }
   // para cada linha eu procurei o menor valor e armazenei em i[b];

   for(b=0; b<a; b++){
      j[b] = matriz[0][b];
      for(c=1; c<a; c++){
         if(j[b]<matriz[c][b])
            j[b] = matriz[c][b];
      }
      //printf("%d\n", j[b]);
   }
   // para cada coluna eu procurei o menor valor e armazenei em j[b];

   d = 0;
   for(b=0; b<a; b++){
      if(i[b]==j[b]){
         ij[d] = i[b]; // ou = j[b];
         d++;
      }
   }
   /* comparei os valores i e j
   (que eu sei que s�o os menores de cada linha e coluna)
   e guardei em ij[] o valor a que se referem*/

   d = 0;
   for(b=0; b<a; b++){
      for(c=0; c<a; c++){
         if(matriz[b][c]==ij[b]){
            printf("\nA[%d,%d]=%d   refere a um ponto de sela\n", b+1, c+1, ij[b]);
            d++;
         }
      }
   }
   if(d==0)
      printf("\nN�o existem pontos de sela\n");
   // se existem, os pontos de sela s�o exibidos

   getch();
   return 0;
}


