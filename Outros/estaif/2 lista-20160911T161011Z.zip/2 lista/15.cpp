#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#define l 4
#define c 8
#define tam 4
/*Fa�a um programa que preencha um array bidimensional 8 x 16 com n�meros inteiros e some cada uma
das linhas desse array, armazenando o resultado das somas em um array unidimensional. A seguir, o
programa dever� multiplicar cada elemento do array bidimensional pela soma da linha correspondente e
mostrar o array bidimensional resultante:*/
int main()
{
    setlocale(LC_ALL,"ptb");
	
	long int a[l][c],vet[tam],b[l][c],i,j;
		
	printf("\tArray original\n\n\n");
		
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			a[i][j]=1+rand()%2;
			vet[i]+=a[i][j];
			printf(" %5d ",a[i][j]);
			
		}
		printf("\n\n\n");
	}
		
	printf("\tArray resultande\n\n\n");
				
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			b[i][j]=vet[i]*a[i][j];
			printf(" %5d ",b[i][j]);		
		}
		printf("\n\n\n");
	}



	
	exit(1);
}




