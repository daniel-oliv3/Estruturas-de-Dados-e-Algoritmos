#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#define l 3
#define c 6
/*Crie um programa que tenha um array 3 x 6 de valores reais, onde as linhas representam tr�s vendedores
em uma loja de sapatos e as colunas representam os meses de janeiro a junho. Cada elemento desse array
deve representar quanto o respectivo vendedor vendeu em cada m�s. Em seguida, exiba o total de vendas
por vendedor durante os 6 meses, identificando o vendendor:*/

int main()
{
    setlocale(LC_ALL,"ptb");
	float ven[l][c],t[l];
	int i,j;
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			ven[i][j]=rand()%10;
			if(i==0){
				t[i]+=ven[i][j];
			}
			else if(i==1){
				t[i]+=ven[i][j];
			}
			else if(i==2){
				t[i]+=ven[i][j];
			}
			printf(" %.2f ",ven[i][j]);
		}		
		printf("\n\n");
	}
	for(i=0;i<l;i++){
		printf("A vendedora %d vendeu: %.2f\n",i+1,t[i]);
	}
	

	printf("\n\n");
	system("pause");
	exit(1);

}






