#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#define l 2
#define c 2
/*Um elemento Aij de um array bidimensional � dito como ponto de sela do array A se, e somente se, Aij for
ao mesmo tempo, o menor elemento da linha i e o maior elemento da coluna j. Fa�a um programa que
carregue um array bidimensional de ordem 5 x 7, em seguida verifique se o array A possui ponto de sela e,
se possuir, mostre seu valor e sua localiza��o:*/

int main()
{
    setlocale(LC_ALL,"ptb");
    
    int a[l][c],i,j,ml[l],mc[l],x[l],f;
	srand(time(NULL));

	for(i=0;i<l;i++){
		for(j=0;j<c;j++){	
			printf("Informe um valor[%d][%d] ",i,j);
			scanf("%d",&a[i][j]);
		}
	}

	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			//a[i][j]=1+rand()%20;
			printf(" %5d ",a[i][j]);
		}
		printf("\n\n\n");
	}


	for(i=0;i<l;i++){

		ml[i]=a[i][0];

		for(j=1;j<c;j++){

			if(ml[i]>a[i][j]){
				ml[i]=a[i][j];		
			}
		}
	}	
	
	for(i=0;i<l;i++){

		mc[i]=a[0][i];

		for(j=1;j<c;j++){

			if(mc[i]<a[j][i]){
				mc[i]=a[j][i];		
			}
		}
	}
	
	for(i=0;i<l;i++){
		
		if(ml[i]==mc[i]){
			x[i]=ml[i];
		}
	}

	f=0;
		
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){

			if(a[i][j]==x[i]){
				printf("\nA[%d,%d]=%d   refere a um ponto de sela\n",i+1,j+1,x[i]);
				f++;
			}			
		}
	}

	if(f==0){
		printf("N�o existe ponto de sela\n");
	}	

	printf("\n\n");
	system("pause");
	exit(1);

}





