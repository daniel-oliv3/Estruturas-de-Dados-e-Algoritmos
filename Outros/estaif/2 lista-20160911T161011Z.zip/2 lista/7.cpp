#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#define l 10
#define c 10
/* */

int main()
{
    setlocale(LC_ALL,"ptb");

	int i,j,a[l][c];
	srand(time(NULL));
	
	printf("\nArray Original\n");

	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			if(i<j){
				a[i][j]=(2*i)+(7*j)-2;	
			}
			else if(i==j){
				a[i][j]=3*(pow(i,3))-1;
			}
			else if(i>j){
				a[i][j]=4*(pow(i,3))+5*(pow(j,2))+1;
			}
			printf(" %5d ",a[i][j]);
		}
		printf("\n\n");
	}

	printf("\n\n");
	system("pause");
	exit(1);

}






