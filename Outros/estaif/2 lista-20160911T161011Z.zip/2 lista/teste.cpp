#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#define l 5
#define c 5
/*Fa�a um programa que leia um array bidimensional de tamanho 4 x 4 com valores num�ricos inteiros e
positivos. Imprimir o array com os valores ordenados sequencialmente por linha em ordem crescente: */

int main()
{
    setlocale(LC_ALL,"ptb");
	
	int a[l][c],i,j,k,m,x;
	
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			printf("  [%d][%d]  ",i,j);
		}		
		printf("\n\n");
	}
	
	printf("\n\n");
	system("pause");
	exit(1);

}


