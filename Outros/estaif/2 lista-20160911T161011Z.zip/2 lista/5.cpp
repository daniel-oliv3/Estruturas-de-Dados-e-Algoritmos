#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#define l 4
#define c 4
/* */

int main()
{
    setlocale(LC_ALL,"ptb");
	
	int i,j,a[l][c],max,lin,col;
	
	srand(time(NULL));
	
	printf("\nArray Original\n");

	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			a[i][j]=rand()%10;
			printf(" %5d ",a[i][j]);
			if(i==0 and j==0){
				max=a[i][j];
			}
			else if(a[i][j]>max){
				max=a[i][j];
				lin=i;
				col=j;
			}
		}
		printf("\n\n");
	}
	printf("O maior elemento: %d - Linha: %d - Coluna: %d\n",max,lin,col);

	printf("\n\n");
	system("pause");
	exit(1);

}






