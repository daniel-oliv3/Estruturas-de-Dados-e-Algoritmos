#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#define l 10
#define c 10
/* Elabore um programa que preencha um array bidimensional de ordem 10 x 10 com n�meros inteiros,
execute as trocas especificadas a seguir e mostre o array resultante:
a) A linha 3 com a linha 9
b) A coluna 4 com a coluna 10
c) A diagonal principal com a diagonal secund�ria
d) A linha 2 com a coluna 8*/

int main()
{
    setlocale(LC_ALL,"ptb");
	
	int a[l][c],b[l][c],i,j,x,y[10],z[10];
	srand(time(NULL));

	printf("\tArray original\n\n\n");
		
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			a[i][j]=1+rand()%10;
			printf(" %5d ",a[i][j]);
		}
		printf("\n\n\n");
	}
	
		printf("\n\n\n");
			printf("\n\n\n");
			
	for(i=0;i<l;i++){
		x=a[2][i];
		a[2][i]=a[8][i];
		a[8][i]=x;	
	}
	for(i=0;i<l;i++){
		x=a[i][3];
		a[i][3]=a[i][9];
		a[i][9]=x;
	}
	
	for(i=0;i<l;i++){
		x=a[1][i];
		a[1][i]=a[i][7];
		a[i][7]=x;
	}
			
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			if(i==j){
				y[i]=a[i][j];
			}
		}
		
	}
	
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			if(i+j==l-1){
				z[i]=a[i][j];
			}
		}
		
	}
	
	
	
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			if(i+j==l-1){
				a[i][j]=y[i];
			}
		}
		
	}
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			if(i==j){
				a[i][j]=z[i];
			}
		}
		
	}
	
	
	
			
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
		
			printf(" %5d ",a[i][j]);
		}
		printf("\n\n\n");
	}
	
	printf("\n\n\n");
	
	for(i=0;i<l;i++){
			printf(" %5d ",y[i]);
	}
	
	printf("\n\n\n");
	
	for(i=0;i<l;i++){
			printf(" %5d ",z[i]);
	}
	
	
	

		
		
		

		

	printf("\n\n");
	system("pause");
	exit(1);

}






