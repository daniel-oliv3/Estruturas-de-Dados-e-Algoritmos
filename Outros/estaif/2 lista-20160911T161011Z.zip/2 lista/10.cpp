#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#define l 8
#define c 8
/* */

int main()
{
    setlocale(LC_ALL,"ptb");
	int i,j,a[l][c],max,min;
	srand(time(NULL));
	
	printf("\nArray Original\n");

	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			a[i][j]=rand()%10;
			printf(" %5d ",a[i][j]);
		}
		printf("\n\n");
	}
	min=a[4][0];
	min=a[4][0];
	
	for(i=4;i<=4;i++){
		for(j=0;j<c;j++){
			if(a[i][j]<min){
				min=a[i][j];	
			}
			else if(a[i][j]>max){
				max=a[i][j];
			}
		}
	}
	printf("O maior: %d - O menor: %d da linha 5\n",max,min);

	min=a[0][6];
	min=a[0][6];
	
	for(i=0;i<l;i++){
		for(j=6;j<=6;j++){
			if(a[i][j]<min){
				min=a[i][j];	
			}
			else if(a[i][j]>max){
				max=a[i][j];
			}
		}
	}
	printf("\n\nO maior: %d - O menor: %d da coluna 7\n",max,min);

	printf("\n\n");
	system("pause");
	exit(1);

}






