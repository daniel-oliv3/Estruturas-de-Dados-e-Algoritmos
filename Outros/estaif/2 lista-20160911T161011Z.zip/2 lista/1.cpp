#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#define l 5
#define c 5
/* */

int main()
{
    setlocale(LC_ALL,"ptb");
	
	int x,i,j,a[l][c];
	
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			a[i][j]=rand()%10;
			printf(" %5d ",a[i][j]);
		}
		printf("\n\n");
	}
	
	do{
		printf("\nQual linha vc dejesa imprimir\n");
		scanf("%d",&x);
	
	}while(x<0 or x>4);
		
	
	for(i=x;i<=x;i++){
		for(j=0;j<l;j++){
			printf(" %5d ",a[i][j]);
		}
		printf("\n\n");
	}

	printf("\n\n");
	system("pause");
	exit(1);

}






